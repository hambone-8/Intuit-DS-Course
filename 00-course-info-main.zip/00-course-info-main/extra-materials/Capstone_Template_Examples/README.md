# ClassChallenges
Fun but Optional challenges to the class


This Repo is open to edits from the entire class. We'll use it to hold your submissions to various class challenges offered throughout the course.

Participation is entirely optional
